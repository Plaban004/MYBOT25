from flask import Flask, render_template, request, jsonify, session
import openai
import logging

openai.api_key = 'YOUR_OPENAI_API_KEY'

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Setup logging
logging.basicConfig(filename='chatbot.log', level=logging.INFO)

@app.route("/")
def home():
    session['history'] = []
    return render_template("index.html")

@app.route("/get", methods=["POST"])
def chatbot_response():
    user_input = request.json["msg"]
    history = session.get("history", [])
    messages = [{"role": "system", "content": "You are a friendly assistant that remembers previous context."}]
    for entry in history:
        messages.append({"role": "user", "content": entry['user']})
        messages.append({"role": "assistant", "content": entry['bot']})
    messages.append({"role": "user", "content": user_input})

    try:
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=messages
        )
        bot_reply = response["choices"][0]["message"]["content"]
    except Exception as e:
        bot_reply = "Sorry, I'm having trouble connecting to OpenAI."

    history.append({"user": user_input, "bot": bot_reply})
    session["history"] = history
    logging.info(f"User: {user_input} | Bot: {bot_reply}")
    return jsonify({"reply": bot_reply})

if __name__ == "__main__":
    app.run(debug=True)
